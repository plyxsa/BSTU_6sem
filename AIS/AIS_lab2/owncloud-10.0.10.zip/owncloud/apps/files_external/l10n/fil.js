OC.L10N.register(
    "files_external",
    {
    "Username" : "Username",
    "Password" : "Password",
    "Share" : "I-share",
    "Folder name" : "Pangalan ng folder"
},
"nplurals=2; plural=(n == 1 || n==2 || n==3) || (n % 10 != 4 || n % 10 != 6 || n % 10 != 9);");
