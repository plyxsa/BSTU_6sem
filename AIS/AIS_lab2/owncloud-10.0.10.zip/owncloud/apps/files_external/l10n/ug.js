OC.L10N.register(
    "files_external",
    {
    "External storage" : "سىرتقى ساقلىغۇچ",
    "Personal" : "شەخسىي",
    "Username" : "ئىشلەتكۈچى ئاتى",
    "Password" : "ئىم",
    "Save" : "ساقلا",
    "Port" : "ئېغىز",
    "WebDAV" : "WebDAV",
    "URL" : "URL",
    "Location" : "ئورنى",
    "ownCloud" : "ownCloud",
    "Host" : "باش ئاپپارات",
    "Share" : "ھەمبەھىر",
    "Name" : "ئاتى",
    "Folder name" : "قىسقۇچ ئاتى",
    "Configuration" : "سەپلىمە",
    "Delete" : "ئۆچۈر"
},
"nplurals=1; plural=0;");
