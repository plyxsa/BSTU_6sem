<?php
$TRANSLATIONS = array(
"Your personal web services. All your files, contacts, calendar and more, in one place." => "Dịch vụ web cá nhân của bạn. Mọi file, liên hệ, lịch của bạn và nhiều hơn thế  trong 1 nơi duy nhất",
"Get the apps to sync your files" => "Nhận ứng dụng để đồng bộ file của bạn",
"Connect your Calendar" => "Kết nối tới lịch của bạn",
"Connect your Contacts" => "Kết nối tới liên lạc của bạn",
"Access files via WebDAV" => "Truy cập file qua WebDAV",
"Documentation" => "Tài liệu hướng dẫn",
"There’s more information in the <a target=\"_blank\" href=\"%s\">documentation</a> and on our <a target=\"_blank\" href=\"http://owncloud.org\">website</a>." => "Để có nhiều thông tin hơn vui lòng xem trong  <a target=\"_blank\" href=\"%s\">tài liệu</a> và trên <a target=\"_blank\" href=\"http://owncloud.org\">website</a>."
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
