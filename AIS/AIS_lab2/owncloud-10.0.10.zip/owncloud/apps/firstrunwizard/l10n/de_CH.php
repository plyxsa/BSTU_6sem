<?php
$TRANSLATIONS = array(
"Your personal web services. All your files, contacts, calendar and more, in one place." => "Ihre persönlichen Web-Services. Alle Ihre Dateien, Kontakte, Kalender und mehr an einem Ort.",
"Get the apps to sync your files" => "Laden Sie die Apps zur Synchronisierung Ihrer Daten herunter",
"Connect your Calendar" => "Verbinden Sie Ihre Kalender ",
"Connect your Contacts" => "Verbinden Sie Ihre Kontakte",
"Access files via WebDAV" => "Greifen Sie auf Dateien über WebDAV zu",
"Documentation" => "Dokumentation"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
